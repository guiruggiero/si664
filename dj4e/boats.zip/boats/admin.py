from django.contrib import admin
from boats.models import Type, Boat

# Register your models here.

admin.site.register(Type)
admin.site.register(Boat)